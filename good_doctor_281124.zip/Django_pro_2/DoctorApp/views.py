from django.shortcuts import render, get_object_or_404, redirect
from DoctorApp.models import Pacjent, Wizyta
from django.forms import modelform_factory


def index(request):
    return render(request, "wizyta.html", {"Pacjenci":Pacjent.objects.all(), "Wizyty":Wizyta.objects.all()})

def detail(request, id):
    context = get_object_or_404(Pacjent, pk=id)
    return render(request, "detail.html", {"Pacjenci": context })



visitForm = modelform_factory(Wizyta, exclude=[])
def add_wizyta(request):
    if request.method == "POST":
        form = visitForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect("index")
    else:
        form = visitForm()
    return render(request, "add_wizyta.html",{"form":form})
