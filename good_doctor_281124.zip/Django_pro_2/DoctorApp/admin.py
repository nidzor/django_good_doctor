from django.contrib import admin
from DoctorApp.models import Pacjent, Wizyta

admin.site.register(Pacjent)
admin.site.register(Wizyta)