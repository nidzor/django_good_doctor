from django.contrib import admin
from django.urls import path
from . import views

urlpatterns = [
    path('detail/<int:id>', views.detail, name = 'detail'),
    path('add_wizyta', views.add_wizyta, name = 'add_wizyta'),
]
