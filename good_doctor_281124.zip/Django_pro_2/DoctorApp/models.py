from django.db import models

class Pacjent(models.Model):
    Nazwisko = models.TextField(default="")
    Imie = models.TextField(default="")
    Miasto = models.TextField(default="Białystok")
    Ulica = models.TextField(default="")
    Wiek = models.IntegerField(default=1)
    def __str__(self):
        return f"{self.Imie} {self.Nazwisko}"

class Wizyta(models.Model):
    Data = models.DateField()
    Zalecenia = models.TextField(default="")
    Pacjent = models.ForeignKey(Pacjent, on_delete=models.CASCADE)
    def __str__(self):
        return f"{self.Data} {self.Pacjent.Nazwisko}"